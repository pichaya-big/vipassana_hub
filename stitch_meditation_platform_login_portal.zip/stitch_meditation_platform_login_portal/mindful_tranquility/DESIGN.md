---
name: Mindful Tranquility
colors:
  surface: '#f8f9ff'
  surface-dim: '#d0dbed'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dee9fc'
  surface-container-highest: '#d9e3f6'
  on-surface: '#121c2a'
  on-surface-variant: '#414944'
  inverse-surface: '#27313f'
  inverse-on-surface: '#eaf1ff'
  outline: '#717973'
  outline-variant: '#c0c9c2'
  surface-tint: '#3a6752'
  primary: '#134230'
  on-primary: '#ffffff'
  primary-container: '#2d5a46'
  on-primary-container: '#9fcfb6'
  inverse-primary: '#a1d1b8'
  secondary: '#85530b'
  on-secondary: '#ffffff'
  secondary-container: '#fdb96b'
  on-secondary-container: '#774800'
  tertiary: '#2a4032'
  on-tertiary: '#ffffff'
  tertiary-container: '#405749'
  on-tertiary-container: '#b2cbb9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bceed3'
  primary-fixed-dim: '#a1d1b8'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#224f3c'
  secondary-fixed: '#ffddba'
  secondary-fixed-dim: '#fdb96b'
  on-secondary-fixed: '#2b1700'
  on-secondary-fixed-variant: '#673d00'
  tertiary-fixed: '#cfe9d6'
  tertiary-fixed-dim: '#b3cdbb'
  on-tertiary-fixed: '#0a2014'
  on-tertiary-fixed-variant: '#354c3e'
  background: '#f8f9ff'
  on-background: '#121c2a'
  surface-variant: '#d9e3f6'
typography:
  display:
    fontFamily: Noto Serif
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 60px
    letterSpacing: -0.01em
  display-mobile:
    fontFamily: Noto Serif
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 46px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 42px
    letterSpacing: 0em
  headline-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 26px
    fontWeight: '400'
    lineHeight: 34px
    letterSpacing: 0em
  headline-md:
    fontFamily: Noto Serif
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 34px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Noto Serif
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: 0em
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0.015em
  label-lg:
    fontFamily: Manrope
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: Manrope
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-tablet: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style

This design system embodies the serene, contemplative essence of Vipassana Bhavana and Satipatthana meditation. It translates classical Buddhist monastic restraint, warm natural materials, and breath-centered mindfulness into an ethereal, distraction-free digital atmosphere.

### Philosophy & Tone
- **Calm & Present:** Interactions are fluid, soft, and unhurried. Negative space acts as visual silence, allowing the user's mind to settle.
- **Organic & Grounded:** Natural off-whites, botanical greens, and meditative monastic ochre/terracotta draw directly from forest monastery sanctuaries and traditional natural dyed robes.
- **Respectful & Focused:** High clarity and gentle visual hierarchy eliminate sensory overload, fostering devotion, continuity of awareness, and ease of practice.

### Aesthetic Movement
A synthesis of **Organic Warm Minimalism** and **Subtle Tactility**. Flat planes are enriched by soft layered ivories, delicate vegetal tone-on-tone lines, and whispers of organic diffuse illumination rather than heavy dropshadows or harsh structural breaks.

## Colors

The palette draws directly from natural and monastic environments—forest leaves, stone stupas, raw unbleached linen, and warm monastic clay.

### Role Definitions
- **Primary (`#2D5A46` Deep Forest Sage):** The color of steady concentration and sanctuary. Used for primary calls to action, active navigation states, audio playback progression, and foundational semantic accents. A lighter companion (`#3B755D`) handles hover and soft-emphasis states.
- **Secondary (`#C58940` Warm Monastic Terracotta/Amber):** Represents the light of insight (*pañña*) and traditional monk robe tones. Used judiciously for milestones, meditation timers, active audio bookmarks, and focal points. Paired with soft amber tint (`#D4A373`).
- **Tertiary (`#738B7B` Muted Herb / Celadon):** Bridges deep greens and background neutrals, serving for secondary indicators, passive tags, and subtle progress indicators.
- **Neutral Surface & Base:**
  - Base Background: `#FAF8F5` (warm ivory paper).
  - Raised Surface / Card: `#FFFFFF` (clean presence) and `#F4EFEB` (secondary canvas/soft stone).
  - Subtle Border / Hairline: `#E7DFD5` (linen wash).
- **Typography & High Contrast:**
  - Text Primary: `#1F2937` (softened charcoal, warmer than pitch black).
  - Text Secondary: `#4B5563` (weathered slate).
  - Text Muted: `#78716C` (warm stone gray).

## Typography

The type system blends reverent classical presence with effortless digital reading. 

- **Headlines (`Noto Serif`):** Conveys timeless scriptural gravity, echoing traditional stone and palm-leaf manuscripts while rendering with exceptional clarity. For Thai multilingual implementations, fallback directly to `Noto Serif Thai` or `Sarabun` to maintain seamless optical harmony.
- **Body & Labels (`Manrope`):** A modern, geometric grotesque with humanist open counters that breathe well on the screen. For Thai body text, pair with `Noto Sans Thai` or `Sarabun` at matched baseline metrics.
- **Rhythm & Line Height:** Line heights are intentionally loosened (1.6x - 1.7x relative ratio) to evoke tranquility and prevent cognitive friction during long meditative readings and Dhamma study sessions.

## Layout & Spacing

A centered, content-first layout system designed to draw attention to contemplation and Dhamma lectures without visual clutter.

### Layout Rhythm
- **Reading Sanctuary:** Long-form teachings, sutta studies, and guided meditation scripts maintain an optimal reading measure capped at 680px width, centered within the canvas.
- **Grid Layout:** Dashboard and curriculum views follow a 12-column fluid grid on desktop, 8-column on tablet, and 4-column on mobile.
- **Negative Space:** Empty vertical space is treated as an active design asset. Significant breath gaps (`space-xl` and above) separate meditative practice blocks from instructional commentary.

## Elevation & Depth

Visual hierarchy uses warm, diffuse atmospheric depth rather than hard artificial drop-shadows.

### Elevation Tiers
- **Tier 0 (Base Ground):** The raw ivory canvas (`#FAF8F5`). Everything rests calmly here.
- **Tier 1 (Resting Cards & Surfaces):** White or pale linen tiles (`#FFFFFF` or `#F4EFEB`) bounded by a subtle outline in `#E7DFD5` (1px solid) with an ambient shadow: `0 4px 20px -2px rgba(45, 90, 70, 0.04)`.
- **Tier 2 (Interactive Floating Modules / Audio Tray):** Used for persistent audio players, floating meditation timers, and interactive menus: `0 12px 32px -4px rgba(45, 90, 70, 0.08)`.
- **Tier 3 (Modals / Overlays):** Used for deep retreat mode or focused introspection dialogues: `0 24px 48px -8px rgba(31, 41, 55, 0.12)`, backed by a gentle warm backdrop blur (`rgba(250, 248, 245, 0.8)` with `backdrop-filter: blur(8px)`).

## Shapes

The design system embraces gentle, rounded contours inspired by river-smoothed stones, clay alms bowls, and natural lotus petals.

- **Base Radius (0.5rem / 8px):** Applied to inputs, dropdowns, and nested interactive elements.
- **Medium Radius (1rem / 16px):** Standard for practice cards, reflection notes, and instructional containers.
- **Large Radius (1.5rem / 24px):** Used for hero modules, audio player bars, and major feature panels.
- **Full Radius (Pill):** Dedicated strictly to status chips, tags, audio progress tracks, and primary call-to-action buttons.

## Components

### Buttons
- **Primary:** Forest sage background (`#2D5A46`), pure white text, pill-shaped contour. On hover, shifts softly to `#3B755D` with an ambient glow. Focus state: 2px offset ring in `#C58940`.
- **Secondary (Terracotta Accent):** Monastic amber (`#C58940`), white text, used for reflective milestones or "Begin Meditation" entry points.
- **Tertiary / Ghost:** Transparent background with `#2D5A46` text and an optional `#E7DFD5` border. On hover, adopts a faint sage tint (`rgba(45, 90, 70, 0.05)`).

### Cards (Bhavana Modules & Sutta Cards)
- Pure white or soft cream surface, rounded-lg (16px), 1px subtle linen border (`#E7DFD5`).
- Generous internal padding (`space-lg`).
- Interactive meditation cards feature an inner breathing progress indicator or a delicate terracotta icon tag.

### Input Fields & Search
- Background: `#FFFFFF` against ivory canvas, or `#F4EFEB` within white cards.
- Border: 1px `#E7DFD5`, transitioning on focus to `#2D5A46` accompanied by a soft halo: `box-shadow: 0 0 0 3px rgba(45, 90, 70, 0.15)`.
- Placeholder text in soft stone gray (`#78716C`).

### Checkboxes & Radio Buttons
- Custom circular styling for both radio and checkboxes to evoke fullness and peace.
- Active state fills with `#2D5A46` exhibiting a miniature ivory dot or smooth checkmark, bordered with calm precision.

### Chips & Tags (Satipatthana Foundations)
- Pill-shaped labels used to denote the Four Foundations: *Kayanupassana* (Body), *Vedananupassana* (Feelings), *Cittanupassana* (Mind), *Dhammanupassana* (Dhammas).
- Light botanical backgrounds (`rgba(45, 90, 70, 0.08)`) with crisp sage text (`#2D5A46`) or amber tint (`rgba(197, 137, 64, 0.12)` with `#C58940` text).

### Specialized Domain Components
- **Meditation Audio Bar:** Persistent docked bar with a slender timeline track, warm amber scrub head, floating play/pause bell trigger, and natural interval chime selectors.
- **Mindful Breath Bell Modal:** Minimalist timer interface dominated by a smooth pulsing ring visualizing inhalation and exhalation rhythm, devoid of digital clutter.